from distutils.core import setup
setup(
	name = 'pyso_project',
	packages = ['pkgA','pkgB'],
	py_module = ['pyso_project'],
	version = '1.0',
	description = 'My First Project',
	author = 'Pyso',
	auther_email = 'willk61will@gmail.com',
	keywords = ['Start a try'],
	classifiers = [],
)

